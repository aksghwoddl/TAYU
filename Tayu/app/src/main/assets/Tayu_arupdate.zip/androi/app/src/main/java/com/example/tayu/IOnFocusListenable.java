package com.example.tayu;

public interface IOnFocusListenable {
    public void onWindowFocusChanged(boolean hasFocus);
}
